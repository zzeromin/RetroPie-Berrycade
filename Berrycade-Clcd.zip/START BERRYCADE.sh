/opt/retropie/configs/all/runcommand-onstart_berrycade.sh Berrycade "Select Game Plz"&
/opt/retropie/emulators/advmame/3.1/bin/advmenu
