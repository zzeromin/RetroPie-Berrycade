/opt/retropie/configs/all/runcommand-onstart_berrycade.sh Berrycade "Select Game Please"&
/home/pi/.advance/advmenu
