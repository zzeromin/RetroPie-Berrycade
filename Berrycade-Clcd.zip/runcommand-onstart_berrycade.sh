#!/usr/bin/env bash

system=$1
init_message=$2

LOG=/dev/shm/runcommand.log
echo "$system" > $LOG
echo "$init_message" >> $LOG

emul=`ps -ef | grep -v grep | grep advmenu | awk '{print $8}' | cut -d/ -f5`
rom_prev=""

while [[ "$emul" != "" ]]
do

 emul=`ps -ef | grep -v grep | grep advmenu | awk '{print $8}' | cut -d/ -f5`
 rom=`ps -ef | grep -v grep | grep advmame | awk '{print $9}'`

 while [[ "$rom" != "$rom_prev" ]]
  do
   rom=`ps -ef | grep -v grep | grep advmame | awk '{print $9}'`

   if [[ "$rom" != "" ]]
   then
	rom_bn="${rom}.zip"

	GAMELIST1="/home/pi/RetroPie/roms/mame-advmame/gamelist.xml"
	GAMELIST2="/home/pi/.emulationstation/gamelists/mame-advmame/gamelist.xml"

	if [ -f ${GAMELIST} ]
	then
	GAMELIST=${GAMELIST1}
	else
	GAMELIST=${GAMELIST2}
	fi

	title=`grep -A1 "${rom_bn}" ${GAMELIST} | awk '{getline;print}' | awk 'BEGIN {FS="<name>"} {print $2}' | awk 'BEGIN {FS="</name>"} {print $1}'`

	echo "$system" > $LOG
	echo "$title" >> $LOG
   else
	echo "$system" > $LOG
	echo "$init_message" >> $LOG
   fi
	rom_prev=$rom
  done
  sleep 3
done
